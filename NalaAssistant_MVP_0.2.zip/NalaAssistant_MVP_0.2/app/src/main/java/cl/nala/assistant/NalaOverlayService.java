package cl.nala.assistant;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.File;

public class NalaOverlayService extends Service {
    public static final String ACTION_SHOW="cl.nala.assistant.SHOW", ACTION_HIDE="cl.nala.assistant.HIDE";
    private static final int NOTIF_ID=731; private static final String CHANNEL="nala_companion";
    private WindowManager wm; private FrameLayout root; private ImageView avatar; private WindowManager.LayoutParams params;
    private Handler handler=new Handler(Looper.getMainLooper()); private String mode="always"; private boolean compact=false; private AnimatorSet idleAnim;
    private final Runnable compactRun=()->{if("contextual".equals(mode)&&root!=null)compact(true);};

    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);createChannel();}
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null&&ACTION_HIDE.equals(i.getAction())){remove();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
        mode=i!=null?i.getStringExtra("mode"):null;if(mode==null)mode=getSharedPreferences("nala",MODE_PRIVATE).getString("mode","always");
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;} startForeground(NOTIF_ID,notification()); show(); return START_STICKY;
    }
    private void show(){
        remove();
        root=new FrameLayout(this); avatar=new ImageView(this); avatar.setImageDrawable(loadAvatar(this)); avatar.setScaleType(ImageView.ScaleType.FIT_CENTER); root.addView(avatar,new FrameLayout.LayoutParams(-1,-1));
        int s=dp(getSharedPreferences("nala",MODE_PRIVATE).getInt("size",62)+42);
        params=new WindowManager.LayoutParams(s,s,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START; params.x=getSharedPreferences("nala",MODE_PRIVATE).getInt("x",dp(12)); params.y=getSharedPreferences("nala",MODE_PRIVATE).getInt("y",dp(180));
        Touch touch=new Touch();root.setOnTouchListener(touch);wm.addView(root,params);startIdle();scheduleCompact();
    }
    private void startIdle(){
        if(avatar==null)return; if(idleAnim!=null)idleAnim.cancel();
        ObjectAnimator bob=ObjectAnimator.ofFloat(avatar,"translationY",0f,-dp(7),0f);bob.setDuration(2400);bob.setRepeatCount(ValueAnimator.INFINITE);
        ObjectAnimator sway=ObjectAnimator.ofFloat(avatar,"rotation",-1.5f,1.5f,-1.5f);sway.setDuration(3600);sway.setRepeatCount(ValueAnimator.INFINITE);
        ObjectAnimator breatheX=ObjectAnimator.ofFloat(avatar,"scaleX",1f,1.025f,1f);breatheX.setDuration(3000);breatheX.setRepeatCount(ValueAnimator.INFINITE);
        ObjectAnimator breatheY=ObjectAnimator.ofFloat(avatar,"scaleY",1f,1.025f,1f);breatheY.setDuration(3000);breatheY.setRepeatCount(ValueAnimator.INFINITE);
        idleAnim=new AnimatorSet();idleAnim.playTogether(bob,sway,breatheX,breatheY);idleAnim.start();
    }
    private void compact(boolean yes){if(root==null)return;compact=yes;int base=getSharedPreferences("nala",MODE_PRIVATE).getInt("size",62);int s=dp(yes?50:base+42);params.width=s;params.height=s;snap();safeUpdate();root.animate().alpha(yes?.82f:1f).setDuration(250).start();}
    private void scheduleCompact(){handler.removeCallbacks(compactRun);if("contextual".equals(mode))handler.postDelayed(compactRun,7000);}
    private void snap(){Point p=new Point();wm.getDefaultDisplay().getSize(p);params.x=params.x+params.width/2<p.x/2?dp(4):Math.max(dp(4),p.x-params.width-dp(4));params.y=Math.max(dp(40),Math.min(params.y,p.y-params.height-dp(90)));}
    private void safeUpdate(){try{wm.updateViewLayout(root,params);}catch(Exception ignored){}}
    private void remove(){handler.removeCallbacks(compactRun);if(idleAnim!=null)idleAnim.cancel();try{if(root!=null)wm.removeView(root);}catch(Exception ignored){}root=null;avatar=null;}

    public static Drawable loadAvatar(Context c){
        if(c.getSharedPreferences("nala",MODE_PRIVATE).getBoolean("customAvatar",false)){
            File f=new File(c.getFilesDir(),"custom_avatar.png");if(f.exists()){Drawable d=Drawable.createFromPath(f.getAbsolutePath());if(d!=null)return d;}
        }
        return c.getDrawable(cl.nala.assistant.R.drawable.nala_avatar);
    }

    private class Touch implements View.OnTouchListener{
        float downX,downY;int startX,startY;long downT;boolean moved;
        public boolean onTouch(View v,android.view.MotionEvent e){
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN: downX=e.getRawX();downY=e.getRawY();startX=params.x;startY=params.y;downT=System.currentTimeMillis();moved=false;if(idleAnim!=null)idleAnim.pause();return true;
                case MotionEvent.ACTION_MOVE:int dx=(int)(e.getRawX()-downX),dy=(int)(e.getRawY()-downY);if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5))moved=true;params.x=startX+dx;params.y=startY+dy;safeUpdate();return true;
                case MotionEvent.ACTION_UP:
                    if(idleAnim!=null)idleAnim.resume();
                    if(moved){snap();safeUpdate();getSharedPreferences("nala",MODE_PRIVATE).edit().putInt("x",params.x).putInt("y",params.y).apply();scheduleCompact();}
                    else if(System.currentTimeMillis()-downT<650){ if(compact){compact(false);scheduleCompact();}else{Intent open=new Intent(NalaOverlayService.this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(open);} }
                    return true;
            }return false;
        }
    }
    private Notification notification(){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent h=new Intent(this,NalaOverlayService.class).setAction(ACTION_HIDE);PendingIntent hi=PendingIntent.getService(this,1,h,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);return b.setContentTitle("Nala está activa").setContentText("Tócala para darle instrucciones").setSmallIcon(android.R.drawable.star_big_on).setOngoing(true).setContentIntent(pi).addAction(new Notification.Action.Builder(null,"Ocultar",hi).build()).build();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Nala flotante",NotificationManager.IMPORTANCE_LOW);c.setShowBadge(false);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    @Override public void onDestroy(){remove();super.onDestroy();}@Override public android.os.IBinder onBind(Intent i){return null;}private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
}
