package cl.nala.assistant;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.FrameLayout;

public class NalaOverlayService extends Service {
    public static final String ACTION_SHOW = "cl.nala.assistant.SHOW";
    public static final String ACTION_HIDE = "cl.nala.assistant.HIDE";
    private static final int NOTIF_ID = 731;
    private static final String CHANNEL = "nala_companion";

    private WindowManager wm;
    private CatView cat;
    private WindowManager.LayoutParams params;
    private Handler handler = new Handler(Looper.getMainLooper());
    private String mode = "always";
    private final Runnable compactRunnable = () -> { if ("contextual".equals(mode) && cat != null) compact(true); };

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_HIDE.equals(intent.getAction())) {
            removeOverlay(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
            return START_NOT_STICKY;
        }
        mode = intent != null ? intent.getStringExtra("mode") : null;
        if (mode == null) mode = getSharedPreferences("nala", MODE_PRIVATE).getString("mode", "always");
        if (!Settings.canDrawOverlays(this) || "hidden".equals(mode)) {
            stopSelf(); return START_NOT_STICKY;
        }
        startForeground(NOTIF_ID, notification());
        showOverlay();
        return START_STICKY;
    }

    private void showOverlay() {
        if (cat != null) { scheduleCompact(); return; }
        cat = new CatView(this);
        int size = dp(74);
        params = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        int savedX = getSharedPreferences("nala", MODE_PRIVATE).getInt("x", dp(16));
        int savedY = getSharedPreferences("nala", MODE_PRIVATE).getInt("y", dp(180));
        params.x = savedX; params.y = savedY;
        cat.currentX=params.x; cat.currentY=params.y;
        cat.setOnMove((x,y) -> { params.x=x; params.y=y; cat.currentX=x; cat.currentY=y; safeUpdate(); });
        cat.setOnMoveEnd((x,y) -> {
            snapToEdge();
            cat.currentX=params.x; cat.currentY=params.y;
            getSharedPreferences("nala", MODE_PRIVATE).edit().putInt("x",params.x).putInt("y",params.y).apply();
            scheduleCompact();
        });
        cat.setOnTap(() -> {
            if (cat.compact) { compact(false); scheduleCompact(); return; }
            Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(open);
        });
        cat.setOnLongPress(() -> {
            getSharedPreferences("nala", MODE_PRIVATE).edit().putString("mode","hidden").apply();
            removeOverlay(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        });
        wm.addView(cat, params);
        scheduleCompact();
    }

    private void compact(boolean yes) {
        if (cat == null) return;
        cat.compact = yes; cat.invalidate();
        int s = dp(yes ? 38 : 74);
        params.width=s; params.height=s;
        snapToEdge(); safeUpdate();
    }

    private void scheduleCompact() {
        handler.removeCallbacks(compactRunnable);
        if ("contextual".equals(mode)) handler.postDelayed(compactRunnable, 5000);
        else if (cat != null && cat.compact) compact(false);
    }

    private void snapToEdge() {
        if (cat == null || params == null) return;
        Point p = new Point(); wm.getDefaultDisplay().getSize(p);
        int w = params.width;
        params.x = params.x + w/2 < p.x/2 ? dp(6) : Math.max(dp(6), p.x - w - dp(6));
        params.y = Math.max(dp(40), Math.min(params.y, p.y - params.height - dp(80)));
    }

    private void safeUpdate() { try { if (cat != null) wm.updateViewLayout(cat, params); } catch (Exception ignored) {} }
    private void removeOverlay() { handler.removeCallbacks(compactRunnable); try { if (cat != null) wm.removeView(cat); } catch(Exception ignored){} cat=null; }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent hide = new Intent(this, NalaOverlayService.class).setAction(ACTION_HIDE);
        PendingIntent hi = PendingIntent.getService(this, 1, hide, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Nala está contigo")
                .setContentText("Toca para abrir · mantén Nala pulsada para ocultarla")
                .setSmallIcon(android.R.drawable.star_big_on)
                .setOngoing(true).setContentIntent(pi)
                .addAction(new Notification.Action.Builder(null, "Ocultar", hi).build())
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Nala flotante", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Mantiene activa la compañera flotante Nala"); c.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() { removeOverlay(); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent intent) { return null; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    static class CatView extends View {
        interface Move { void call(int x,int y); }
        interface Tap { void call(); }
        Move onMove; Move onMoveEnd; Tap onTap; Tap onLongPress;
        float downRawX, downRawY; int startX,startY; int currentX=0,currentY=0; long downTime; boolean moved; boolean compact=false; Handler h=new Handler(Looper.getMainLooper());
        Runnable longRun = () -> { if (!moved && onLongPress != null) onLongPress.call(); };
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Paint stroke=new Paint(Paint.ANTI_ALIAS_FLAG);

        CatView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(2)); stroke.setStrokeCap(Paint.Cap.ROUND); }
        void setOnMove(Move m){onMove=m;} void setOnMoveEnd(Move m){onMoveEnd=m;} void setOnTap(Tap t){onTap=t;} void setOnLongPress(Tap t){onLongPress=t;}

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
            p.setShadowLayer(dp(8),0,dp(3),0x66000000); p.setColor(Color.rgb(39,34,49)); c.drawCircle(cx,cy,Math.min(w,h)*.47f,p); p.clearShadowLayer();
            if (compact) {
                p.setColor(Color.rgb(197,155,255)); c.drawCircle(cx,cy,Math.min(w,h)*.28f,p); return;
            }
            p.setColor(Color.rgb(197,155,255));
            Path ears=new Path(); ears.moveTo(w*.25f,h*.39f); ears.lineTo(w*.25f,h*.13f); ears.lineTo(w*.43f,h*.30f); ears.close(); c.drawPath(ears,p);
            ears.reset(); ears.moveTo(w*.75f,h*.39f); ears.lineTo(w*.75f,h*.13f); ears.lineTo(w*.57f,h*.30f); ears.close(); c.drawPath(ears,p);
            c.drawOval(w*.22f,h*.25f,w*.78f,h*.80f,p);
            p.setColor(Color.rgb(28,26,34)); c.drawCircle(w*.41f,h*.49f,dp(3),p); c.drawCircle(w*.59f,h*.49f,dp(3),p);
            Path nose=new Path(); nose.moveTo(cx,h*.57f); nose.lineTo(cx-dp(4),h*.54f); nose.lineTo(cx+dp(4),h*.54f); nose.close(); c.drawPath(nose,p);
            stroke.setColor(Color.rgb(28,26,34)); c.drawLine(cx,h*.57f,cx,h*.63f,stroke); c.drawArc(cx-dp(10),h*.58f,cx,h*.64f,0,70,false,stroke); c.drawArc(cx,h*.58f,cx+dp(10),h*.64f,110,70,false,stroke);
            for(int i=-1;i<=1;i+=2){ float y=h*(i==-1?.58f:.64f); c.drawLine(w*.29f,y,w*.10f,y-dp(2),stroke); c.drawLine(w*.71f,y,w*.90f,y-dp(2),stroke); }
            p.setColor(Color.rgb(246,242,255)); p.setTextSize(dp(10)); p.setTextAlign(Paint.Align.CENTER); c.drawText("NALA",cx,h*.93f,p);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX=e.getRawX(); downRawY=e.getRawY(); startX=currentX; startY=currentY; downTime=System.currentTimeMillis(); moved=false; h.postDelayed(longRun,650); return true;
                case MotionEvent.ACTION_MOVE:
                    int dx=(int)(e.getRawX()-downRawX), dy=(int)(e.getRawY()-downRawY);
                    if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5)){moved=true;h.removeCallbacks(longRun);}
                    if(onMove!=null) onMove.call(startX+dx,startY+dy); return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    h.removeCallbacks(longRun);
                    int fx=(int)(startX+e.getRawX()-downRawX), fy=(int)(startY+e.getRawY()-downRawY);
                    if(moved){if(onMoveEnd!=null) onMoveEnd.call(fx,fy);} else if(System.currentTimeMillis()-downTime<650 && onTap!=null) onTap.call(); return true;
            }
            return super.onTouchEvent(e);
        }
        private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    }
}
