package cl.nala.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 4120;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        requestNotificationsIfNeeded();
    }

    private View buildUi() {
        int pad = dp(22);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(23, 21, 29));

        TextView icon = text("🐱", 58, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon, matchWrap());

        TextView title = text("Nala", 32, Color.rgb(246,242,255), true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = text("Tu compañera flotante en Android", 16, Color.rgb(190,182,203), false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = matchWrap();
        sp.bottomMargin = dp(28);
        root.addView(subtitle, sp);

        TextView modeTitle = text("Cómo quieres verla", 17, Color.WHITE, true);
        modeTitle.setPadding(0,0,0,dp(8));
        root.addView(modeTitle, matchWrap());

        RadioGroup modes = new RadioGroup(this);
        modes.setOrientation(RadioGroup.VERTICAL);
        RadioButton always = radio("Siempre visible");
        RadioButton contextual = radio("Contextual · se hace pequeña al borde");
        RadioButton hidden = radio("Oculta");
        always.setId(1001); contextual.setId(1002); hidden.setId(1003);
        modes.addView(always); modes.addView(contextual); modes.addView(hidden);
        String current = getSharedPreferences("nala", MODE_PRIVATE).getString("mode", "always");
        modes.check("contextual".equals(current) ? 1002 : ("hidden".equals(current) ? 1003 : 1001));
        modes.setOnCheckedChangeListener((group, checkedId) -> {
            String mode = checkedId == 1002 ? "contextual" : (checkedId == 1003 ? "hidden" : "always");
            getSharedPreferences("nala", MODE_PRIVATE).edit().putString("mode", mode).apply();
            if (checkedId == 1003) stopNala();
            else if (Settings.canDrawOverlays(this)) startNala(mode);
        });
        LinearLayout.LayoutParams mp = matchWrap();
        mp.bottomMargin = dp(22);
        root.addView(modes, mp);

        Button show = button("Mostrar Nala");
        show.setOnClickListener(v -> ensureOverlayAndStart());
        root.addView(show, fullButton());

        Button hide = button("Ocultar Nala");
        hide.setOnClickListener(v -> stopNala());
        LinearLayout.LayoutParams hp = fullButton();
        hp.topMargin = dp(10);
        root.addView(hide, hp);

        TextView help = text("Primera vez: Android te pedirá permiso para ‘mostrar sobre otras apps’. Actívalo para que Nala pueda aparecer encima de cualquier aplicación.\n\nArrástrala para moverla. Tócala para volver a Nala. Mantén pulsado para ocultarla.", 14, Color.rgb(190,182,203), false);
        help.setPadding(0, dp(26), 0, 0);
        root.addView(help, matchWrap());

        return root;
    }

    private void ensureOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_OVERLAY);
            return;
        }
        String mode = getSharedPreferences("nala", MODE_PRIVATE).getString("mode", "always");
        if ("hidden".equals(mode)) {
            mode = "always";
            getSharedPreferences("nala", MODE_PRIVATE).edit().putString("mode", mode).apply();
        }
        startNala(mode);
    }

    private void startNala(String mode) {
        Intent s = new Intent(this, NalaOverlayService.class);
        s.setAction(NalaOverlayService.ACTION_SHOW);
        s.putExtra("mode", mode);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        Toast.makeText(this, "Nala está activa", Toast.LENGTH_SHORT).show();
    }

    private void stopNala() {
        Intent s = new Intent(this, NalaOverlayService.class);
        s.setAction(NalaOverlayService.ACTION_HIDE);
        startService(s);
        Toast.makeText(this, "Nala se ocultó", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) ensureOverlayAndStart();
            else Toast.makeText(this, "Necesito ese permiso para aparecer sobre otras apps", Toast.LENGTH_LONG).show();
        }
    }

    private void requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 901);
        }
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private RadioButton radio(String s) {
        RadioButton r = new RadioButton(this);
        r.setText(s); r.setTextColor(Color.rgb(246,242,255)); r.setTextSize(16); r.setPadding(0,dp(3),0,dp(3));
        return r;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(16); b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams fullButton() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
