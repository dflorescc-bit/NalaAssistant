package cl.nala.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.os.BatteryManager;
import java.text.SimpleDateFormat;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.Normalizer;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 4120;
    private static final int REQ_IMAGE = 4121;
    private static final int REQ_SPEECH = 4122;
    private EditText command;
    private TextView response;
    private ImageView preview;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(buildUi());
        requestNotificationsIfNeeded();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(26));
        root.setBackgroundColor(Color.rgb(21,19,27));
        scroll.addView(root);

        preview = new ImageView(this);
        preview.setImageDrawable(NalaOverlayService.loadAvatar(this));
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(185));
        root.addView(preview, pp);

        TextView title = text("Nala · v0.3", 29, Color.rgb(247,243,255), true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, fullWrap());
        TextView sub = text("Tu compañera flotante y asistente de acciones", 15, Color.rgb(190,182,203), false);
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,0,0,dp(18)); root.addView(sub, fullWrap());

        root.addView(section("Dale una instrucción"), fullWrap());
        command = new EditText(this);
        command.setHint("Ej: abre WhatsApp · busca taladro inalámbrico");
        command.setHintTextColor(Color.rgb(145,139,156));
        command.setTextColor(Color.WHITE);
        command.setSingleLine(true);
        command.setInputType(InputType.TYPE_CLASS_TEXT);
        command.setBackgroundColor(Color.rgb(35,32,45));
        command.setPadding(dp(14),0,dp(14),0);
        root.addView(command, new LinearLayout.LayoutParams(-1, dp(54)));

        LinearLayout sendRow = row();
        Button send = button("Enviar");
        send.setOnClickListener(v -> executeCommand(command.getText().toString()));
        Button mic = button("🎤 Hablar");
        mic.setOnClickListener(v -> startVoiceInput());
        sendRow.addView(send, weight());
        sendRow.addView(mic, weight());
        LinearLayout.LayoutParams sp = fullWrap(); sp.topMargin=dp(8); root.addView(sendRow, sp);

        response = text("Puedes pedirme que abra aplicaciones, busque en la web, muestre u oculte a Nala o cambie su modo.", 14, Color.rgb(197,155,255), false);
        response.setPadding(dp(4),dp(10),dp(4),dp(18)); root.addView(response, fullWrap());

        root.addView(section("Acciones rápidas"), fullWrap());
        LinearLayout q1 = row();
        q1.addView(quickFromPref(1, "WhatsApp", "abre WhatsApp"), weight());
        q1.addView(quickFromPref(2, "YouTube", "abre YouTube"), weight());
        root.addView(q1, fullWrap());
        LinearLayout q2 = row();
        q2.addView(quickFromPref(3, "Chrome", "abre Chrome"), weight());
        q2.addView(quickFromPref(4, "Cámara", "abre cámara"), weight());
        root.addView(q2, fullWrap());
        Button editQuick = button("Editar accesos rápidos");
        editQuick.setOnClickListener(v -> editQuickActions());
        LinearLayout.LayoutParams eqp=fullButton(); eqp.topMargin=dp(6); root.addView(editQuick,eqp);

        root.addView(section("Nala flotante"), withTop(dp(16)));
        Button show = button("Mostrar Nala"); show.setOnClickListener(v -> ensureOverlayAndStart()); root.addView(show, fullButton());
        Button hide = button("Ocultar Nala"); hide.setOnClickListener(v -> stopNala()); LinearLayout.LayoutParams hp=fullButton(); hp.topMargin=dp(8); root.addView(hide,hp);

        RadioGroup modes = new RadioGroup(this); modes.setOrientation(RadioGroup.VERTICAL);
        RadioButton a=radio("Siempre visible"), c=radio("Contextual · se hace pequeña al borde");
        a.setId(101); c.setId(102); modes.addView(a); modes.addView(c);
        String m=prefs().getString("mode","always"); modes.check("contextual".equals(m)?102:101);
        modes.setOnCheckedChangeListener((g,id)->{ String nm=id==102?"contextual":"always"; prefs().edit().putString("mode",nm).apply(); if(Settings.canDrawOverlays(this)) startNala(nm); });
        root.addView(modes, fullWrap());

        root.addView(section("Personalización"), withTop(dp(16)));
        Button avatar = button("Elegir PNG de mascota");
        avatar.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_IMAGE);
        });
        root.addView(avatar, fullButton());

        TextView sizeLabel=text("Tamaño del personaje",15,Color.WHITE,true); sizeLabel.setPadding(0,dp(14),0,0); root.addView(sizeLabel,fullWrap());
        SeekBar size = new SeekBar(this); size.setMax(100); size.setProgress(prefs().getInt("size",62)-45);
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean f){ prefs().edit().putInt("size",45+p).apply(); } public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){ if(Settings.canDrawOverlays(MainActivity.this)) startNala(prefs().getString("mode","always")); }});
        root.addView(size, fullWrap());

        TextView help = text("Comandos incluidos:\n• abre [aplicación]\n• busca [texto]\n• abre cámara / ajustes / navegador / teléfono / mapas\n• abre Wi‑Fi / Bluetooth\n• ¿qué hora es? / batería\n• muéstrate / ocúltate\n• modo contextual / siempre visible\n\nToca a Nala para abrir este panel. Arrástrala para moverla.", 14, Color.rgb(190,182,203), false);
        help.setPadding(0,dp(20),0,0); root.addView(help,fullWrap());
        return scroll;
    }

    private void executeCommand(String raw) {
        String q = raw == null ? "" : raw.trim();
        if(q.isEmpty()){ say("Dime qué quieres que haga."); return; }
        String n = norm(q);
        if(n.equals("muestrate") || n.contains("mostrar nala") || n.equals("aparece")) { ensureOverlayAndStart(); say("Aquí estoy."); return; }
        if(n.equals("ocultate") || n.contains("ocultar nala") || n.equals("escondete")) { stopNala(); say("Me oculto. Puedes volver a abrirme desde la app."); return; }
        if(n.contains("modo contextual")) { prefs().edit().putString("mode","contextual").apply(); if(Settings.canDrawOverlays(this)) startNala("contextual"); say("Modo contextual activado."); return; }
        if(n.contains("siempre visible")) { prefs().edit().putString("mode","always").apply(); if(Settings.canDrawOverlays(this)) startNala("always"); say("Quedaré siempre visible."); return; }
        if(n.equals("que hora es") || n.equals("hora") || n.contains("dime la hora")) { say("Son las " + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()) + "."); return; }
        if(n.contains("bateria")) { BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE); int pct=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); say("Tu batería está en " + pct + "%."); return; }
        if(n.contains("abre telefono") || n.equals("telefono") || n.equals("marcador")) { safeStart(new Intent(Intent.ACTION_DIAL)); say("Abriendo el teléfono."); return; }
        if(n.contains("abre mapas") || n.equals("mapas")) { safeStart(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))); say("Abriendo mapas."); return; }
        if(n.contains("abre wifi") || n.equals("wifi")) { safeStart(new Intent(Settings.ACTION_WIFI_SETTINGS)); say("Abriendo Wi‑Fi."); return; }
        if(n.contains("abre bluetooth") || n.equals("bluetooth")) { safeStart(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); say("Abriendo Bluetooth."); return; }
        if(n.startsWith("busca ") || n.startsWith("buscar ")) {
            String term=q.substring(q.indexOf(' ')+1).trim();
            openUrl("https://www.google.com/search?q=" + Uri.encode(term)); say("Buscando: " + term); return;
        }
        if(n.contains("abre ajustes") || n.equals("ajustes")) { safeStart(new Intent(Settings.ACTION_SETTINGS)); say("Abriendo Ajustes."); return; }
        if(n.contains("abre camara") || n.equals("camara")) { safeStart(new Intent(MediaStore.ACTION_IMAGE_CAPTURE)); say("Abriendo la cámara."); return; }
        if(n.contains("abre navegador") || n.equals("navegador")) { openUrl("https://www.google.com"); say("Abriendo el navegador."); return; }
        if(n.startsWith("abre ") || n.startsWith("abrir ") || n.startsWith("abre la aplicacion ")) {
            String wanted = q.replaceFirst("(?i)^abre la aplicaci[oó]n\\s+", "").replaceFirst("(?i)^(abre|abrir)\\s+", "").trim();
            if(openInstalledApp(wanted)) say("Abriendo " + wanted + ".");
            else say("No encontré una aplicación llamada “" + wanted + "”. Prueba con el nombre que aparece bajo su icono.");
            return;
        }
        say("Aún no sé ejecutar esa instrucción. En esta versión puedo abrir apps, buscar en la web y controlar mi personaje flotante.");
    }

    private boolean openInstalledApp(String wanted) {
        String target=norm(wanted);
        PackageManager pm=getPackageManager();
        Intent base=new Intent(Intent.ACTION_MAIN); base.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps=pm.queryIntentActivities(base, PackageManager.MATCH_ALL);
        ResolveInfo best=null; int score=-1;
        for(ResolveInfo r:apps){
            String label=String.valueOf(r.loadLabel(pm)); String nl=norm(label);
            int s=0;
            if(nl.equals(target)) s=100;
            else if(nl.contains(target) || target.contains(nl)) s=80;
            else {
                for(String part:target.split(" ")) if(part.length()>2 && nl.contains(part)) s+=15;
            }
            if(s>score){score=s;best=r;}
        }
        if(best!=null && score>=15){
            Intent launch=pm.getLaunchIntentForPackage(best.activityInfo.packageName);
            if(launch!=null){ launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); return true; }
        }
        return false;
    }

    private void safeStart(Intent i){ try{ startActivity(i); }catch(Exception e){ say("No encontré una app compatible para esa acción."); } }
    private void openUrl(String url){ safeStart(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
    private void say(String s){ response.setText(s); Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    private void startVoiceInput(){
        try{
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());
            i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Dile una instrucción a Nala");
            startActivityForResult(i,REQ_SPEECH);
        }catch(Exception e){ say("El reconocimiento de voz no está disponible en este teléfono."); }
    }

    private Button quickFromPref(int idx,String defLabel,String defCmd){
        String label=prefs().getString("quick_label_"+idx,defLabel);
        String cmd=prefs().getString("quick_cmd_"+idx,defCmd);
        return quick(label,cmd);
    }

    private void editQuickActions(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(8),dp(16),0);
        final EditText[] labels=new EditText[4]; final EditText[] cmds=new EditText[4];
        String[] dl={"WhatsApp","YouTube","Chrome","Cámara"}; String[] dc={"abre WhatsApp","abre YouTube","abre Chrome","abre cámara"};
        for(int i=0;i<4;i++){
            labels[i]=new EditText(this); labels[i].setHint("Nombre acceso "+(i+1)); labels[i].setText(prefs().getString("quick_label_"+(i+1),dl[i])); box.addView(labels[i]);
            cmds[i]=new EditText(this); cmds[i].setHint("Comando"); cmds[i].setText(prefs().getString("quick_cmd_"+(i+1),dc[i])); box.addView(cmds[i]);
        }
        new android.app.AlertDialog.Builder(this).setTitle("Editar accesos rápidos").setView(box).setPositiveButton("Guardar",(d,w)->{
            SharedPreferences.Editor e=prefs().edit();
            for(int i=0;i<4;i++){e.putString("quick_label_"+(i+1),labels[i].getText().toString().trim());e.putString("quick_cmd_"+(i+1),cmds[i].getText().toString().trim());}
            e.apply(); recreate();
        }).setNegativeButton("Cancelar",null).show();
    }

    private void ensureOverlayAndStart(){
        if(!Settings.canDrawOverlays(this)){ startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())),REQ_OVERLAY); return; }
        startNala(prefs().getString("mode","always"));
    }
    private void startNala(String mode){ Intent s=new Intent(this,NalaOverlayService.class).setAction(NalaOverlayService.ACTION_SHOW).putExtra("mode",mode); if(Build.VERSION.SDK_INT>=26) startForegroundService(s); else startService(s); }
    private void stopNala(){ Intent s=new Intent(this,NalaOverlayService.class).setAction(NalaOverlayService.ACTION_HIDE); startService(s); }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==REQ_OVERLAY && Settings.canDrawOverlays(this)) ensureOverlayAndStart();
        if(req==REQ_SPEECH && result==RESULT_OK && data!=null){
            ArrayList<String> results=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(results!=null && !results.isEmpty()){ command.setText(results.get(0)); executeCommand(results.get(0)); }
        }
        if(req==REQ_IMAGE && result==RESULT_OK && data!=null && data.getData()!=null){
            try{
                Uri uri=data.getData();
                try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=openFileOutput("custom_avatar.png",MODE_PRIVATE)){
                    byte[] buf=new byte[8192]; int len; while((len=in.read(buf))>0) out.write(buf,0,len);
                }
                prefs().edit().putBoolean("customAvatar",true).apply(); preview.setImageDrawable(NalaOverlayService.loadAvatar(this));
                if(Settings.canDrawOverlays(this)) startNala(prefs().getString("mode","always"));
                say("Nueva mascota aplicada.");
            }catch(Exception e){ say("No pude leer esa imagen."); }
        }
    }

    private SharedPreferences prefs(){return getSharedPreferences("nala",MODE_PRIVATE);}    
    private void requestNotificationsIfNeeded(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},901); }
    private String norm(String s){ String n=Normalizer.normalize(s.toLowerCase(Locale.ROOT),Normalizer.Form.NFD).replaceAll("\\p{M}",""); return n.replaceAll("[^a-z0-9 ]"," ").replaceAll("\\s+"," ").trim(); }
    private TextView section(String s){ TextView t=text(s,18,Color.WHITE,true); t.setPadding(0,dp(6),0,dp(8)); return t; }
    private Button quick(String label,String cmd){ Button b=button(label); b.setOnClickListener(v->{command.setText(cmd);executeCommand(cmd);}); return b; }
    private LinearLayout row(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setPadding(0,dp(4),0,dp(4)); return r; }
    private LinearLayout.LayoutParams weight(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1); p.setMargins(dp(3),0,dp(3),0); return p; }
    private TextView text(String s,int sp,int color,boolean bold){ TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t; }
    private RadioButton radio(String s){RadioButton r=new RadioButton(this);r.setText(s);r.setTextColor(Color.WHITE);r.setTextSize(15);return r;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);return b;}
    private LinearLayout.LayoutParams fullButton(){return new LinearLayout.LayoutParams(-1,dp(52));}
    private LinearLayout.LayoutParams fullWrap(){return new LinearLayout.LayoutParams(-1,-2);}
    private LinearLayout.LayoutParams withTop(int top){LinearLayout.LayoutParams p=fullWrap();p.topMargin=top;return p;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
