# Nala Assistant – MVP 0.2

Esta es la versión Android nativa del prototipo Nala.

## Qué incluye
- Nala como gato flotante sobre otras aplicaciones.
- Se puede arrastrar por la pantalla y se pega al borde.
- Toque: abre la app Nala.
- Mantener pulsado: oculta Nala.
- Modo Siempre visible.
- Modo Contextual: tras unos segundos se reduce a una pequeña burbuja al borde.
- Modo Oculta.
- Servicio persistente con notificación discreta.
- Guarda posición y modo.

## Por qué el archivo anterior no se instalaba
`NalaAssistant_MVP_0.1.zip` era un proyecto fuente, no un archivo APK.

## Cómo compilar el APK
1. Abrir esta carpeta en Android Studio.
2. Esperar a que termine Gradle Sync.
3. Build > Build APK(s).
4. El APK debug aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

El teléfono pedirá permiso para "Mostrar sobre otras apps" la primera vez.

## Compatibilidad
- minSdk 26 (Android 8+)
- targetSdk 35
- Diseñado para Android moderno, incluido Samsung/One UI.

## Próxima capa prevista
- Voz.
- Conversación con IA.
- Memoria.
- Personalización del avatar.
- Creador de mascota del usuario.
- Animaciones/estados emocionales.
