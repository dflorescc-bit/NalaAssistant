# Nala Assistant v0.3

MVP Android con personaje flotante basado en Nala, animación suave, comandos locales y apertura de aplicaciones instaladas.

Comandos: `abre WhatsApp`, `abre YouTube`, `busca ...`, `abre cámara`, `abre ajustes`, `ocúltate`, `muéstrate`, `modo contextual`, `siempre visible`.
